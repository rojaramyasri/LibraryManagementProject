package com.example.books.exceptionlayer;

public class NoBookFoundException extends Exception {
	private static final long serialVersionUID = 1L;

	public NoBookFoundException(String message) {
		super(message);
	}
}
