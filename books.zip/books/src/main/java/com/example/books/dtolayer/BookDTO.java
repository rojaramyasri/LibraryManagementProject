package com.example.books.dtolayer;

import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BookDTO {
	
	@NotNull(message = "Book Id should not be null")
	private String id;
	
	@NotNull(message = "Name of book should not be null")
	private String name;
	
	@NotNull(message = "Author name should not be null")
	private String author;
	
	private String publisher;
}
