package com.example.books.exceptionlayer;

public class BookExistedException extends Exception {

	private static final long serialVersionUID = 1L;

	public BookExistedException(String message) {
		super(message);
	}
}
