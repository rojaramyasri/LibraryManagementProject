package com.example.books.exceptionlayer;

public class DuplicateBookEntryException extends Exception {
	private static final long serialVersionUID = 1L;

	public DuplicateBookEntryException(String message) {
		super(message);
	}

}
