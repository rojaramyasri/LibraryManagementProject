package com.example.books.controllerlayer;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.books.databaselayer.BookEntity;
import com.example.books.dtolayer.BookDTO;
import com.example.books.exceptionlayer.BookExistedException;
import com.example.books.exceptionlayer.DuplicateBookEntryException;
import com.example.books.exceptionlayer.NoBookFoundException;
import com.example.books.servicelayer.BookService;

import io.swagger.annotations.Api;

@RestController
@Api
public class BookController {

	@Autowired
	private BookService bookService;

	@PostMapping("/books")
	public BookEntity saveBook(@RequestBody @Valid BookDTO bookDto) throws BookExistedException {
		return bookService.save(bookDto);
	}

	@PutMapping("/books")
	public BookEntity updateBook(@RequestBody @Valid BookDTO bookDto) throws DuplicateBookEntryException {
		return bookService.update(bookDto);
	}

	@GetMapping("/books/{id}")
	public BookEntity getBook(@PathVariable String id) throws NoBookFoundException {
		return bookService.findById(id);
	}

	@GetMapping("/books")
	public List<BookEntity> getBooks() {
		return bookService.findAll();
	}

	@DeleteMapping("/books/{id}")
	public HttpStatus deleteBook(@PathVariable String id) throws NoBookFoundException {
		bookService.delete(id);
		return HttpStatus.OK;
	}
}
