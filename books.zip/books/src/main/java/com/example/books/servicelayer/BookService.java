package com.example.books.servicelayer;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.books.databaselayer.BookEntity;
import com.example.books.databaselayer.BookRepository;
import com.example.books.dtolayer.BookDTO;
import com.example.books.exceptionlayer.BookExistedException;
import com.example.books.exceptionlayer.DuplicateBookEntryException;
import com.example.books.exceptionlayer.NoBookFoundException;

@Service
public class BookService {
	@Autowired
	private BookRepository bookRepo;

	public BookEntity save(BookDTO bookDto) throws BookExistedException {
		ModelMapper mapper = new ModelMapper();
		BookEntity bookEntity = mapper.map(bookDto, BookEntity.class);
		if (bookRepo.findById(bookEntity.getId()).isPresent()) {
			throw new BookExistedException("A book with given id exsited");
		}
		return bookRepo.save(bookEntity);
	}

	public BookEntity update(BookDTO bookDto) throws DuplicateBookEntryException {
		ModelMapper mapper = new ModelMapper();
		BookEntity bookEntity = mapper.map(bookDto, BookEntity.class);
		if (!bookRepo.findById(bookEntity.getId()).isPresent()) {
			throw new DuplicateBookEntryException("A book with given id not found ");
		}
		return bookRepo.save(bookEntity);
	}

	public BookEntity findById(String id) throws NoBookFoundException {
		return bookRepo.findById(id).orElseThrow(
				() -> new NoBookFoundException("Book With given id is not found "));
	}

	public List<BookEntity> findAll() {
		return bookRepo.findAll();
	}

	public void delete(String id) throws NoBookFoundException {
		BookEntity bookEntity = bookRepo.findById(id)
				.orElseThrow(() -> new NoBookFoundException("Book With given id is not found "));
		bookRepo.delete(bookEntity);
	}
}
