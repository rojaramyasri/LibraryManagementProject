package com.example.books;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.hamcrest.Matchers;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.example.books.controllerlayer.BookController;
import com.example.books.databaselayer.BookEntity;
import com.example.books.dtolayer.BookDTO;
import com.example.books.exceptionlayer.BookExistedException;
import com.example.books.exceptionlayer.DuplicateBookEntryException;
import com.example.books.exceptionlayer.NoBookFoundException;
import com.example.books.servicelayer.BookService;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest
class BookControllerTest {
	private MockMvc mockMvc;
	@InjectMocks
	private BookController controller;
	@Mock
	private BookService bookService;
	private BookDTO bookDto;
	private BookEntity bookEntity;

	@BeforeEach
	public void setUp() {
		bookDto = new BookDTO();
		bookEntity = new BookEntity();
		mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
	}

	@Test
	void testSaveBook() throws BookExistedException {
		when(bookService.save(bookDto)).thenReturn(bookEntity);
		assertEquals(bookEntity, controller.saveBook(bookDto));
	}

	@Test
	void testUpdateBook() throws BookExistedException, DuplicateBookEntryException {
		when(bookService.update(bookDto)).thenReturn(bookEntity);
		assertEquals(bookEntity, controller.updateBook(bookDto));
	}

	@Test
	void testDeleteBook() throws NoBookFoundException {
		doNothing().when(bookService).delete(Mockito.anyString());
		assertEquals(HttpStatus.OK, controller.deleteBook(Mockito.anyString()));
	}

	@Test
	void testGetAllBooks() throws Exception {
		List<BookEntity> entities = new ArrayList<>();
		entities.add(bookEntity);
		when(bookService.findAll()).thenReturn(entities);
		mockMvc.perform(get("/books").accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
				.andExpect(jsonPath("[0].id", Matchers.is(bookEntity.getId())))
				.andExpect(jsonPath("[0].author", Matchers.is(bookEntity.getAuthor())))
				.andExpect(jsonPath("[0].publisher", Matchers.is(bookEntity.getPublisher())))
				.andExpect(jsonPath("[0].name", Matchers.is(bookEntity.getName())));
	}

	@Test
	void testGetBook() throws Exception {
		when(bookService.findById(Mockito.anyString())).thenReturn(bookEntity);
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.findAndRegisterModules();
		bookEntity.setId("1");
		String bookDetails = objectMapper.writeValueAsString(bookEntity);
		mockMvc.perform(get("/books/{id}", bookEntity.getId()).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andExpect(content().string(bookDetails));
	}
}
