package com.example.books;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.books.databaselayer.BookEntity;
import com.example.books.databaselayer.BookRepository;
import com.example.books.dtolayer.BookDTO;
import com.example.books.exceptionlayer.BookExistedException;
import com.example.books.exceptionlayer.DuplicateBookEntryException;
import com.example.books.exceptionlayer.NoBookFoundException;
import com.example.books.servicelayer.BookService;

@SpringBootTest
class BookServiceTest {

	@InjectMocks
	private BookService bookService;
	@Mock
	private BookRepository bookRepo;
	private BookDTO bookDto;
	private BookEntity bookEntity;

	@BeforeEach
	public void setUp() {
		bookDto = new BookDTO();
		bookDto.setAuthor("stine");
		bookDto.setId("1");
		bookDto.setName("snowman");
		bookDto.setPublisher("abc");
	}

	@Test
	void testSaveBookException() throws BookExistedException {
		bookEntity = new BookEntity();
		bookEntity.setAuthor("stine");
		bookEntity.setId("1");
		bookEntity.setName("snowman");
		bookEntity.setPublisher("abc");
		when(bookRepo.findById(Mockito.anyString())).thenReturn(Optional.ofNullable(bookEntity));
		assertThrows(BookExistedException.class, () -> {
			bookService.save(bookDto);
		});
	}

	@Test
	void testSaveBook() throws BookExistedException {
		when(bookRepo.findById(Mockito.anyString())).thenReturn(Optional.ofNullable(bookEntity));
		when(bookRepo.save(Mockito.any(BookEntity.class))).thenReturn(Mockito.any(BookEntity.class));
		bookService.save(bookDto);
		verify(bookRepo, atLeastOnce()).save(Mockito.any(BookEntity.class));
	}

	@Test
	void testUpdateBook() throws DuplicateBookEntryException {
		bookEntity = new BookEntity();
		bookEntity.setAuthor("stine");
		bookEntity.setId("1");
		bookEntity.setName("snowman");
		bookEntity.setPublisher("abc");
		when(bookRepo.findById(Mockito.anyString())).thenReturn(Optional.ofNullable(bookEntity));
		when(bookRepo.save(Mockito.any(BookEntity.class))).thenReturn(Mockito.any(BookEntity.class));
		bookService.update(bookDto);
		verify(bookRepo, atLeastOnce()).save(Mockito.any(BookEntity.class));
	}

	@Test
	void testUpdateBookException() throws DuplicateBookEntryException {
		when(bookRepo.findById(Mockito.anyString())).thenReturn(Optional.ofNullable(bookEntity));
		assertThrows(DuplicateBookEntryException.class, () -> {
			bookService.update(bookDto);
		});

	}

	@Test
	void testFindByIdException() {
		when(bookRepo.findById(Mockito.anyString())).thenReturn(Optional.ofNullable(bookEntity));
		assertThrows(NoBookFoundException.class, () -> {
			bookService.findById(Mockito.anyString());
		});
	}

	@Test
	void testFindById() throws NoBookFoundException {
		bookEntity = new BookEntity();
		bookEntity.setAuthor("stine");
		bookEntity.setId("1");
		bookEntity.setName("snowman");
		bookEntity.setPublisher("abc");
		when(bookRepo.findById(Mockito.anyString())).thenReturn(Optional.ofNullable(bookEntity));
		bookService.findById("1");
		assertEquals(bookEntity, bookService.findById(Mockito.anyString()));
	}

	@Test
	void testFindAll() {
		List<BookEntity> entities = new ArrayList<>();
		bookEntity = new BookEntity();
		when(bookService.findAll()).thenReturn(entities);
		assertEquals(entities, bookService.findAll());
	}

	@Test
	void testDeleteBook() throws NoBookFoundException {
		when(bookRepo.findById(Mockito.anyString())).thenReturn(Optional.ofNullable(bookEntity));
		assertThrows(NoBookFoundException.class, () -> {
			bookService.delete(Mockito.anyString());
		});
		bookEntity = new BookEntity();
		bookEntity.setId("1");
		when(bookRepo.findById(Mockito.anyString())).thenReturn(Optional.ofNullable(bookEntity));
		doNothing().when(bookRepo).delete(bookEntity);
		bookService.delete("1");
		verify(bookRepo, atLeastOnce()).delete(Mockito.any(BookEntity.class));
	}

}
