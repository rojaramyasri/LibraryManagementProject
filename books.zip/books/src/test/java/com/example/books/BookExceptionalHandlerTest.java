package com.example.books;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.MethodArgumentNotValidException;

import com.example.books.exceptionlayer.BookExceptionHandler;
import com.example.books.exceptionlayer.BookExistedException;
import com.example.books.exceptionlayer.DuplicateBookEntryException;
import com.example.books.exceptionlayer.NoBookFoundException;

@SpringBootTest
class BookExceptionalHandlerTest {

	@InjectMocks
	private BookExceptionHandler exceptionHandler;
	private static final MethodArgumentNotValidException MethodArgumentNotValidException = null;

	@Test
	void testBookExistedException() {
		BookExistedException exception = new BookExistedException(Mockito.anyString());
		Map<String, String> errors = new LinkedHashMap<>();
		errors.put("time", new Date().toString());
		errors.put("status", HttpStatus.BAD_REQUEST.name());
		errors.put("error", Mockito.anyString());
		assertEquals(errors, exceptionHandler.handleBookExistedException(exception));
	}

	@Test
	void testDuplicateEntryException() {
		DuplicateBookEntryException exception = new DuplicateBookEntryException(Mockito.anyString());
		Map<String, String> errors = new LinkedHashMap<>();
		errors.put("time", new Date().toString());
		errors.put("status", HttpStatus.BAD_REQUEST.name());
		errors.put("error", Mockito.anyString());
		assertEquals(errors, exceptionHandler.handleDuplicateException(exception));
	}

	@Test
	void testNoBookFoundException() {
		NoBookFoundException exception = new NoBookFoundException(Mockito.anyString());
		Map<String, String> errors = new LinkedHashMap<>();
		errors.put("time", new Date().toString());
		errors.put("status", HttpStatus.BAD_REQUEST.name());
		errors.put("error", Mockito.anyString());
		assertEquals(errors, exceptionHandler.handleNoBookFoundException(exception));
	}

	@Test
	void handleMethodArgumentsTest() {
		Map<String, String> errors = new LinkedHashMap<>();
		errors.put("time", new Date().toString());
		errors.put("status", HttpStatus.BAD_REQUEST.name());
		errors.put("error", Mockito.anyString());
		assertEquals(errors, exceptionHandler.handelMethodArgumentException(MethodArgumentNotValidException));
	}
}
