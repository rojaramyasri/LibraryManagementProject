package com.example.library.customexceptions;

import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import feign.FeignException;

@RestControllerAdvice
public class LibraryExceptionHandler {
	
	@ExceptionHandler(FeignException.class)
	@ResponseStatus(code = HttpStatus.BAD_REQUEST)
	public Map<String, String> handelFeignException(FeignException exception)  {
		Map<String, String> errors = new LinkedHashMap<>();
		errors.put("time", new Date().toString());
		errors.put("status", HttpStatus.BAD_REQUEST.name());
		errors.put("error", exception.getMessage());
		return errors;
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	@ResponseStatus(code = HttpStatus.BAD_REQUEST)
	public Map<String, String> handelMethodArgumentException(MethodArgumentNotValidException exception) {
		Map<String, String> errors = new LinkedHashMap<>();
		StringBuilder message = new StringBuilder();
		errors.put("time", new Date().toString());
		errors.put("status", HttpStatus.BAD_REQUEST.name());
		errors.put("error", message.toString());
		return errors;
	}

	@ExceptionHandler(NotFoundException.class)
	@ResponseStatus(code = HttpStatus.BAD_REQUEST)
	public Map<String, String> handleNotFoundException(NotFoundException exception) {
		Map<String, String> errors = new LinkedHashMap<>();
		errors.put("time", new Date().toString());
		errors.put("status", HttpStatus.BAD_REQUEST.name());
		errors.put("error", exception.getMessage());
		return errors;
	}

	@ExceptionHandler(DuplicateEntryException.class)
	@ResponseStatus(code = HttpStatus.BAD_REQUEST)
	public Map<String, String> handelDuplicateEntryException(DuplicateEntryException exception) {
		Map<String, String> errors = new LinkedHashMap<>();
		errors.put("time", new Date().toString());
		errors.put("status", HttpStatus.BAD_REQUEST.name());
		errors.put("error", exception.getMessage());
		return errors;
	}
}
