package com.example.library.dtolayer;

import java.util.List;

import javax.validation.constraints.NotNull;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Component
public class BookUserDTO {
	
	@NotNull(message = "User name should not be null")
	private String userName;
	
	@NotNull(message = "Name should not be null")
	private String name;
	
	private String emailId;
	private List<BookDTO> bookDto;
}
