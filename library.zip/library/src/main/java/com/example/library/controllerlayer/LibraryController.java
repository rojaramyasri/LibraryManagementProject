package com.example.library.controllerlayer;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.library.clients.BookClient;
import com.example.library.clients.UserClient;
import com.example.library.customexceptions.DuplicateEntryException;
import com.example.library.databaselayer.LibraryEntity;
import com.example.library.dtolayer.BookDTO;
import com.example.library.dtolayer.BookUserDTO;
import com.example.library.dtolayer.LibraryDTO;
import com.example.library.dtolayer.UserDTO;
import com.example.library.servicelayer.LibraryService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@Api
public class LibraryController {

	@Autowired
	private UserClient userClient;
	@Autowired
	private BookClient bookClient;
	@Autowired
	private LibraryService libraryService;

	@GetMapping("/library/users")
	@ApiOperation(value = "List of all users")
	public ResponseEntity<List<UserDTO>> getUsersInfo() {
		return new ResponseEntity<>(userClient.getUsers(),HttpStatus.OK);
	}

	@PostMapping("/library/users")
	@ApiOperation(value = "Add a new user")
	public ResponseEntity<UserDTO> registerUser(@RequestBody @Valid UserDTO userDto) {
		return new ResponseEntity<>(userClient.saveUser(userDto), HttpStatus.OK);
	}

	@PutMapping("/library/users")
	@ApiOperation(value = "Update user details")
	public ResponseEntity<UserDTO> updateUser(@RequestBody @Valid UserDTO userDto) {
		return new ResponseEntity<>(userClient.saveUser(userDto), HttpStatus.OK);
	}

	@GetMapping("/library/users/{userName}")
	@ApiOperation(value = "Get information of  user")
	public ResponseEntity<BookUserDTO> getUserDetails(@PathVariable String userName) {
		return new ResponseEntity<>(libraryService.getUserInfo(userName), HttpStatus.OK);
	}

	@DeleteMapping("/library/users/{userName}")
	@ApiOperation(value = "Delete  user")
	public ResponseEntity<HttpStatus> deleteUser(@PathVariable String userName) {
		libraryService.deleteUsers(userName);
		return new ResponseEntity<>(userClient.deleteUser(userName), HttpStatus.OK);
	}

	@GetMapping("/library/books")
	@ApiOperation(value = "Details of books")
	public List<BookDTO> getBooksInfo() {
		return bookClient.getBooks();
	}

	@PostMapping("/library/books")
	@ApiOperation(value = "Add a book")
	public ResponseEntity<BookDTO> registerBook(@RequestBody @Valid BookDTO bookDto) {
		return new ResponseEntity<>(bookClient.saveBook(bookDto),HttpStatus.OK);
	}

	@PutMapping("/library/books")
	@ApiOperation(value = "Update existed book")
	public ResponseEntity<BookDTO> updateBook(@RequestBody @Valid BookDTO bookDto) {
		return new ResponseEntity<>(bookClient.updateBook(bookDto), HttpStatus.OK);
	}

	@GetMapping("/library/books/{bookId}")
	@ApiOperation(value = "Details of a book", notes = "Provide id of a book and should not be null")
	public ResponseEntity<BookDTO> getBookDetails(@PathVariable String bookId) {
		return new ResponseEntity<>(bookClient.getBook(bookId), HttpStatus.OK);
	}

	@DeleteMapping("/library/books/{bookId}")
	@ApiOperation(value = "Delete a book")
	public ResponseEntity<HttpStatus> deleteBookById(@PathVariable String bookId) {
		libraryService.deleteBooks(bookId);
		return new ResponseEntity<>(bookClient.deleteBook(bookId), HttpStatus.OK);
	}

	@PostMapping("/library/register")
	@ApiOperation(value = "Issue a book for user")
	public ResponseEntity<LibraryEntity> register(@RequestBody @Valid LibraryDTO libraryDto)
			throws DuplicateEntryException {
		return new ResponseEntity<>(libraryService.save(libraryDto), HttpStatus.OK);
	}

	@GetMapping("/library/people/{id}")
	@ApiOperation(value = "User info in library data base")
	public ResponseEntity<List<LibraryEntity>> getDetailsOfPerson(@PathVariable String id) {
		return new ResponseEntity<>(libraryService.findAllByUserName(id), HttpStatus.OK);
	}

	@GetMapping("/library/book/{id}")
	@ApiOperation(value = "Book info in library data base")
	public ResponseEntity<List<LibraryEntity>> getDetailsOfBooks(@PathVariable String id) {
		return new ResponseEntity<>(libraryService.findAllByBookId(id), HttpStatus.OK);
	}

	@GetMapping("/library")
	@ApiOperation(value = "List of all users and books")
	public ResponseEntity<List<LibraryEntity>> getLibraryDetails() {
		return new ResponseEntity<>(libraryService.findAll(), HttpStatus.OK);
	}

	@DeleteMapping("/library/person/{userName}")
	@ApiOperation(value = "Delete user from library database")
	public ResponseEntity<HttpStatus> deletePerson(@PathVariable String userName) {
		libraryService.deleteUsers(userName);
		return new ResponseEntity<>(HttpStatus.OK);
	}

	@DeleteMapping("/library/book/{bookId}")
	@ApiOperation(value = "Delete book from library database")
	public ResponseEntity<HttpStatus> deleteBook(@PathVariable String bookId) {
		libraryService.deleteBooks(bookId);
		return new ResponseEntity<>(HttpStatus.OK);
	}
}
