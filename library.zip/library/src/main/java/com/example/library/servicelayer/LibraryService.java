package com.example.library.servicelayer;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.library.clients.BookClient;
import com.example.library.clients.UserClient;
import com.example.library.customexceptions.DuplicateEntryException;
import com.example.library.customexceptions.NotFoundException;
import com.example.library.databaselayer.LibraryEntity;
import com.example.library.databaselayer.LibraryRepository;
import com.example.library.dtolayer.BookDTO;
import com.example.library.dtolayer.BookUserDTO;
import com.example.library.dtolayer.LibraryDTO;

@Service
public class LibraryService {
	@Autowired
	private LibraryRepository libraryRepo;
	@Autowired
	private UserClient userClient;
	@Autowired
	private BookClient bookClient;

	public LibraryEntity save(LibraryDTO libraryDto) throws DuplicateEntryException {
		ModelMapper mapper = new ModelMapper();
		LibraryEntity libraryEntity = mapper.map(libraryDto, LibraryEntity.class);
		if (libraryRepo.findById(libraryDto.getId()).isPresent()) {
			throw new DuplicateEntryException("An entry with the same libarary id existed ");
		}
		return libraryRepo.save(libraryEntity);
	}

	public void delete(String id) throws NotFoundException {
		LibraryEntity libraryEntity = libraryRepo.findById(id).orElseThrow(
				() -> new NotFoundException("An entry with the given library id not existed in the database "));
		libraryRepo.delete(libraryEntity);
	}

	public LibraryEntity findById(String id) throws NotFoundException {
		return libraryRepo.findById(id).orElseThrow(
				() -> new NotFoundException("An entry with the given library id not existed in the database "));
	}

	public List<LibraryEntity> findAll() {
		return libraryRepo.findAll();
	}

	public List<LibraryEntity> findAllByUserName(String userName) {
		return libraryRepo.findAllByUserName(userName);
	}

	public List<LibraryEntity> findAllByBookId(String bookId) {
		return libraryRepo.findAllByBookId(bookId);
	}

	public void deleteUsers(String userName) {
		libraryRepo.deleteAll(libraryRepo.findAllByUserName(userName));
	}

	public void deleteBooks(String bookId) {
		libraryRepo.deleteAll(libraryRepo.findAllByBookId(bookId));
	}

	public BookUserDTO getUserInfo(String userName) {
		ModelMapper mapper = new ModelMapper();
		BookUserDTO user = mapper.map(userClient.getUser(userName), BookUserDTO.class);
		List<BookDTO> bookEntities = new ArrayList<>();
		libraryRepo.findAllByUserName(userName).forEach(entity -> {
			BookDTO bookDto = mapper.map(bookClient.getBook(entity.getBookId()), BookDTO.class);
			bookEntities.add(bookDto);
		});
		user.setBookDto(bookEntities);
		return user;
	}
}
