package com.example.library.dtolayer;

import javax.validation.constraints.NotNull;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Component
public class LibraryDTO {
	
	@NotNull(message = "Library  Id should not be null")
	private String id;
	
	@NotNull(message = "User name should not be null")
	private String userName;
	
	@NotNull(message = "book id should not be null")
	private String bookId;
}
