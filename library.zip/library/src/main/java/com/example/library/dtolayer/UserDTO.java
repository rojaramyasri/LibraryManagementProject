package com.example.library.dtolayer;

import javax.validation.constraints.NotNull;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Component
public class UserDTO {
	
	@NotNull(message="User name should not be null")
	private String userName;
	
	@NotNull(message="Name should not be null")
	private String name;
	
	private String emailId;
}
