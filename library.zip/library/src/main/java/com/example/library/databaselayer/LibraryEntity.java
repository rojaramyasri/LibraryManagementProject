package com.example.library.databaselayer;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


import lombok.Getter;
import lombok.Setter;

@Entity
@Setter
@Getter
@Table(name = "library")
public class LibraryEntity {
	@Id
	private String id;
	private String userName;
	private String bookId;
}
