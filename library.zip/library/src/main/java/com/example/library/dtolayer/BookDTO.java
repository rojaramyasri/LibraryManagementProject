package com.example.library.dtolayer;

import javax.validation.constraints.NotNull;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Component
public class BookDTO {
	
	@NotNull(message="Id  should not be null")
	private String id;
	
	@NotNull(message="name of book should not be null")
	private String name;
	
	@NotNull(message="name of author should not be null")
	private String author;
	
	private String publisher;
}
