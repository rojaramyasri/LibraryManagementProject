package com.example.library.databaselayer;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LibraryRepository extends JpaRepository<LibraryEntity, String> {
	public List<LibraryEntity> findAllByUserName(String userName);
	public List<LibraryEntity> findAllByBookId(String userName);
}
