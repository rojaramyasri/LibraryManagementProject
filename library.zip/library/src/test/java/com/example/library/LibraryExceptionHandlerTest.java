package com.example.library;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.MethodArgumentNotValidException;

import com.example.library.customexceptions.DuplicateEntryException;
import com.example.library.customexceptions.LibraryExceptionHandler;
import com.example.library.customexceptions.NotFoundException;

@SpringBootTest
class LibraryExceptionHandlerTest {
	private static final MethodArgumentNotValidException MethodArgumentNotValidException = null;
	@InjectMocks
	private LibraryExceptionHandler exceptionHandler;

	@Test
	void testDuplicateEntryException() {
		DuplicateEntryException exception = new DuplicateEntryException("duplicate entry");
		Map<String, String> errors = new LinkedHashMap<>();
		errors.put("time", new Date().toString());
		errors.put("status", HttpStatus.BAD_REQUEST.name());
		errors.put("error", "duplicate entry");
		assertEquals(errors, exceptionHandler.handelDuplicateEntryException(exception));
	}

	@Test
	void testNotFoundException() {
		NotFoundException exception = new NotFoundException("not found");
		Map<String, String> errors = new LinkedHashMap<>();
		errors.put("time", new Date().toString());
		errors.put("status", HttpStatus.BAD_REQUEST.name());
		errors.put("error", "not found");
		assertEquals(errors, exceptionHandler.handleNotFoundException(exception));
	}

	@Test
	void handleMethodArgumentsTest() {
		Map<String, String> errors = new LinkedHashMap<>();
		errors.put("time", new Date().toString());
		errors.put("status", HttpStatus.BAD_REQUEST.name());
		errors.put("error", "");
		assertEquals(errors, exceptionHandler.handelMethodArgumentException(MethodArgumentNotValidException));
	}

}
