package com.example.library;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.hamcrest.Matchers;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.example.library.clients.BookClient;
import com.example.library.clients.UserClient;
import com.example.library.controllerlayer.LibraryController;
import com.example.library.customexceptions.DuplicateEntryException;
import com.example.library.customexceptions.NotFoundException;
import com.example.library.databaselayer.LibraryEntity;
import com.example.library.dtolayer.BookDTO;
import com.example.library.dtolayer.BookUserDTO;
import com.example.library.dtolayer.LibraryDTO;
import com.example.library.dtolayer.UserDTO;
import com.example.library.servicelayer.LibraryService;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest
class LibraryControllerTest {
	private MockMvc mockMvc;
	@InjectMocks
	private LibraryController controller;
	@Mock
	private UserClient userClient;
	@Mock
	private BookClient bookClient;
	@Mock
	private LibraryService libraryService;
	private BookDTO bookDto;
	private BookUserDTO bookUserDto;
	private UserDTO userDto;
	private LibraryDTO libraryDto;

	@BeforeEach
	public void intialize() {
		mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
		userDto = new UserDTO();
		userDto.setEmailId("abc@gmail.com");
		userDto.setName("Ramya");
		userDto.setUserName("Ramya_Sri");
		bookDto = new BookDTO();
		bookDto.setAuthor("Stine");
		bookDto.setId("1");
		bookDto.setName("snowman");
		bookDto.setPublisher("abc");
		bookUserDto = new BookUserDTO();
		bookUserDto.setEmailId("abc@gmail.com");
		bookUserDto.setName("Ramya");
		bookUserDto.setUserName("Ramya_Sri");
		List<BookDTO> list = new ArrayList<>();
		list.add(bookDto);
		bookUserDto.setBookDto(list);
	}

	@Test
	void testGetUsersInfo() throws Exception {
		List<UserDTO> peopleList = new ArrayList<>();
		peopleList.add(userDto);

		when(userClient.getUsers()).thenReturn(peopleList);
		mockMvc.perform(get("/library/users").accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
				.andExpect(jsonPath("[0].name", Matchers.is("Ramya")))
				.andExpect(jsonPath("[0].emailId", Matchers.is("abc@gmail.com")))
				.andExpect(jsonPath("[0].userName", Matchers.is("Ramya_Sri")));
	}

	@Test
	void testRegisterUser() {
		when(userClient.saveUser(userDto)).thenReturn(userDto);
		ResponseEntity<UserDTO> user = controller.registerUser(userDto);
		assertThat(user.getStatusCodeValue()).isEqualTo(200);
	}

	@Test
	void testUpdateUser() {
		when(userClient.saveUser(userDto)).thenReturn(userDto);
		ResponseEntity<UserDTO> user = controller.updateUser(userDto);
		assertThat(user.getStatusCodeValue()).isEqualTo(200);
	}

	@Test
	void testGetUserDetails() throws Exception {
		when(libraryService.getUserInfo(userDto.getUserName())).thenReturn(bookUserDto);
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.findAndRegisterModules();
		String userDetails = objectMapper.writeValueAsString(bookUserDto);
		mockMvc.perform(get("/library/users/{userName}", userDto.getUserName()).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andExpect(content().string(userDetails));
	}

	@Test
	void testDeleteUser() throws NotFoundException {
		when(userClient.deleteUser(Mockito.anyString())).thenReturn(HttpStatus.OK);
		doNothing().when(libraryService).delete(Mockito.anyString());
		ResponseEntity<HttpStatus> user = controller.deleteUser(Mockito.anyString());
		assertThat(user.getStatusCodeValue()).isEqualTo(200);
	}

	@Test
	void testGetBooks() throws Exception {
		List<BookDTO> list = new ArrayList<>();
		list.add(bookDto);
		when(bookClient.getBooks()).thenReturn(list);
		mockMvc.perform(get("/library/books").accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
				.andExpect(jsonPath("[0].id", Matchers.is("1"))).andExpect(jsonPath("[0].author", Matchers.is("Stine")))
				.andExpect(jsonPath("[0].publisher", Matchers.is("abc")))
				.andExpect(jsonPath("[0].name", Matchers.is("snowman")));
	}

	@Test
	void testRegisterBook() {
		when(bookClient.saveBook(bookDto)).thenReturn(bookDto);
		ResponseEntity<BookDTO> book = controller.registerBook(bookDto);
		assertThat(book.getStatusCodeValue()).isEqualTo(200);
	}

	@Test
	void testUpdateBook() {
		when(bookClient.updateBook(bookDto)).thenReturn(bookDto);
		ResponseEntity<BookDTO> book = controller.updateBook(bookDto);
		assertThat(book.getStatusCodeValue()).isEqualTo(200);
	}

	@Test
	void testGetBookDetails() throws Exception {
		when(bookClient.getBook(Mockito.anyString())).thenReturn(bookDto);
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.findAndRegisterModules();
		String bookDetails = objectMapper.writeValueAsString(bookDto);
		mockMvc.perform(get("/library/books/{bookId}", bookDto.getId()).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andExpect(content().string(bookDetails));
	}

	@Test
	void testDeleteBookById() {
		when(bookClient.deleteBook(Mockito.anyString())).thenReturn(HttpStatus.OK);
		doNothing().when(libraryService).deleteBooks(Mockito.anyString());
		ResponseEntity<HttpStatus> book = controller.deleteBookById(Mockito.anyString());
		assertThat(book.getStatusCodeValue()).isEqualTo(200);
	}

	@Test
	void testRegister() throws DuplicateEntryException {
		LibraryEntity entity = new LibraryEntity();
		when(libraryService.save(libraryDto)).thenReturn(entity);
		ResponseEntity<LibraryEntity> library = controller.register(libraryDto);
		assertThat(library.getStatusCodeValue()).isEqualTo(200);
	}

	@Test
	void testGetDetailsOfPerson() {
		List<LibraryEntity> list = new ArrayList<>();
		LibraryEntity entity = new LibraryEntity();
		list.add(entity);
		when(libraryService.findAllByUserName(Mockito.anyString())).thenReturn(list);
		ResponseEntity<List<LibraryEntity>> book = controller.getDetailsOfPerson(Mockito.anyString());
		assertThat(book.getStatusCodeValue()).isEqualTo(200);
	}

	@Test
	void testGetDetailsOfBook() {
		List<LibraryEntity> list = new ArrayList<>();
		LibraryEntity entity = new LibraryEntity();
		list.add(entity);
		when(libraryService.findAllByBookId(Mockito.anyString())).thenReturn(list);
		ResponseEntity<List<LibraryEntity>> book = controller.getDetailsOfBooks(Mockito.anyString());
		assertThat(book.getStatusCodeValue()).isEqualTo(200);
	}

	@Test
	void testGetLibraryInfo() {
		List<LibraryEntity> list = new ArrayList<>();
		LibraryEntity entity = new LibraryEntity();
		list.add(entity);
		when(libraryService.findAll()).thenReturn(list);
		ResponseEntity<List<LibraryEntity>> book = controller.getLibraryDetails();
		assertThat(book.getStatusCodeValue()).isEqualTo(200);
	}

	@Test
	void testDeleteBook() {
		doNothing().when(libraryService).deleteBooks(Mockito.anyString());
		ResponseEntity<HttpStatus> library = controller.deleteBook("1");
		assertThat(library.getStatusCodeValue()).isEqualTo(200);
	}

	@Test
	void testDeletePerson() {
		doNothing().when(libraryService).deleteUsers(Mockito.anyString());
		ResponseEntity<HttpStatus> library = controller.deletePerson("ramya");
		assertThat(library.getStatusCodeValue()).isEqualTo(200);
	}
}
