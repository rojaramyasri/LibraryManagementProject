package com.example.library;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.library.clients.BookClient;
import com.example.library.clients.UserClient;
import com.example.library.customexceptions.DuplicateEntryException;
import com.example.library.customexceptions.NotFoundException;
import com.example.library.databaselayer.LibraryEntity;
import com.example.library.databaselayer.LibraryRepository;
import com.example.library.dtolayer.BookDTO;
import com.example.library.dtolayer.LibraryDTO;
import com.example.library.dtolayer.UserDTO;
import com.example.library.servicelayer.LibraryService;

@SpringBootTest
class LibraryServiceTest {

	@InjectMocks
	private LibraryService libraryService;
	@Mock
	private LibraryRepository libraryRepo;
	@Mock
	private UserClient userClient;
	@Mock
	private BookClient bookClient;
	private LibraryEntity libraryEntity;
	private LibraryDTO libraryDto;

	@BeforeEach
	public void setUp() {
		libraryDto = new LibraryDTO();
		libraryDto.setBookId("1");
		libraryDto.setId("2");
		libraryDto.setUserName("ramya");
	}

	@Test
	void testSave() throws DuplicateEntryException {
		when(libraryRepo.save(Mockito.any(LibraryEntity.class))).thenReturn(libraryEntity);
		libraryService.save(libraryDto);
		verify(libraryRepo, atLeastOnce()).save(Mockito.any(LibraryEntity.class));
	}

	@Test
	void testSaveException() {
		libraryEntity = new LibraryEntity();
		libraryEntity.setBookId("1");
		libraryEntity.setId("2");
		libraryEntity.setUserName("ramya");
		when(libraryRepo.findById(Mockito.anyString())).thenReturn(Optional.ofNullable(libraryEntity));
		assertThrows(DuplicateEntryException.class, () -> {
			libraryService.save(libraryDto);
		});
	}

	@Test
	void testDelete() throws NotFoundException {
		libraryEntity = new LibraryEntity();
		libraryEntity.setBookId("1");
		libraryEntity.setId("2");
		libraryEntity.setUserName("ramya");
		doNothing().when(libraryRepo).delete(libraryEntity);
		when(libraryRepo.findById(Mockito.anyString())).thenReturn(Optional.ofNullable(libraryEntity));
		libraryService.delete("2");
		verify(libraryRepo, atLeastOnce()).delete(Mockito.any(LibraryEntity.class));
	}

	@Test
	void testDeleteException() {
		when(libraryRepo.findById(Mockito.anyString())).thenReturn(Optional.ofNullable(libraryEntity));
		assertThrows(NotFoundException.class, () -> {
			libraryService.delete("2");
		});
	}

	@Test
	void testFindById() throws NotFoundException {
		libraryEntity = new LibraryEntity();
		libraryEntity.setBookId("1");
		libraryEntity.setId("2");
		libraryEntity.setUserName("ramya");
		when(libraryRepo.findById(Mockito.anyString())).thenReturn(Optional.ofNullable(libraryEntity));
		libraryService.findById("2");
	}

	@Test
	void testFindByIdException() {
		when(libraryRepo.findById(Mockito.anyString())).thenReturn(Optional.ofNullable(libraryEntity));
		assertThrows(NotFoundException.class, () -> {
			libraryService.findById("2");
		});
	}

	@Test
	void testFinadAll() {
		List<LibraryEntity> list = new ArrayList<>();
		list.add(libraryEntity);
		when(libraryRepo.findAll()).thenReturn(list);
		libraryService.findAll();
		assertEquals(list, libraryService.findAll());
	}

	@Test
	void testFindAllByUserName() {
		libraryEntity = new LibraryEntity();
		libraryEntity.setBookId("1");
		libraryEntity.setId("2");
		libraryEntity.setUserName("ramya");
		List<LibraryEntity> list = new ArrayList<>();
		list.add(libraryEntity);
		when(libraryRepo.findAllByUserName(Mockito.anyString())).thenReturn(list);
		libraryService.findAllByUserName("ramya");
		libraryService.findAllByUserName("ramya_1");
	}

	@Test
	void testFindAllByBookId() {
		libraryEntity = new LibraryEntity();
		libraryEntity.setBookId("1");
		libraryEntity.setId("2");
		libraryEntity.setUserName("ramya");
		List<LibraryEntity> list = new ArrayList<>();
		list.add(libraryEntity);
		when(libraryRepo.findAllByBookId(Mockito.anyString())).thenReturn(list);
		libraryService.findAllByBookId("1");
		libraryService.findAllByBookId("2");
	}

	@Test
	void testDeleteByUserName() {
		libraryEntity = new LibraryEntity();
		libraryEntity.setBookId("1");
		libraryEntity.setId("2");
		libraryEntity.setUserName("ramya");
		List<LibraryEntity> list = new ArrayList<>();
		list.add(libraryEntity);
		when(libraryRepo.findAllByUserName(Mockito.anyString())).thenReturn(list);
		doNothing().when(libraryRepo).deleteAll(Mockito.anyList());
		libraryService.deleteUsers("ramya");
	}

	@Test
	void testDeleteByBookId() {
		libraryEntity = new LibraryEntity();
		libraryEntity.setBookId("1");
		libraryEntity.setId("2");
		libraryEntity.setUserName("ramya");
		List<LibraryEntity> list = new ArrayList<>();
		list.add(libraryEntity);
		when(libraryRepo.findAllByBookId(Mockito.anyString())).thenReturn(list);
		doNothing().when(libraryRepo).deleteAll(Mockito.anyList());
		libraryService.deleteBooks("1");
	}

	@Test
	void testGetUserInfo() {
		libraryEntity = new LibraryEntity();
		libraryEntity.setBookId("1");
		libraryEntity.setId("2");
		libraryEntity.setUserName("ramya");
		UserDTO userDto = new UserDTO();
		userDto.setEmailId("abc@gmail.com");
		userDto.setName("ramya");
		userDto.setUserName("ramya");
		when(userClient.getUser(Mockito.anyString())).thenReturn(userDto);
		BookDTO bookDto = new BookDTO();
		bookDto.setAuthor("stine");
		bookDto.setId("1");
		bookDto.setName("snowman");
		bookDto.setPublisher("abc");
		when(bookClient.getBook(Mockito.anyString())).thenReturn(bookDto);
		List<LibraryEntity> list = new ArrayList<>();
		list.add(libraryEntity);
		when(libraryRepo.findAllByUserName(Mockito.anyString())).thenReturn(list);
		libraryService.getUserInfo("ramya");
	}

}
