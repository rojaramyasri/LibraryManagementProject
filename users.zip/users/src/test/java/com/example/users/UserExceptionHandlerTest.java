package com.example.users;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.MethodArgumentNotValidException;

import com.example.users.exceptionlayer.DuplicateUserEntryException;
import com.example.users.exceptionlayer.NoUserFoundException;
import com.example.users.exceptionlayer.UserExceptionalHandler;
import com.example.users.exceptionlayer.UserExistedException;

@SpringBootTest
class UserExceptionHandlerTest {
	private static final MethodArgumentNotValidException MethodArgumentNotValidException = null;

	@InjectMocks
	private UserExceptionalHandler exceptionHandler;

	@Test
	void testBookExistedException() {
		UserExistedException exception = new UserExistedException(Mockito.anyString());
		Map<String, String> errors = new LinkedHashMap<>();
		errors.put("time", new Date().toString());
		errors.put("status", HttpStatus.BAD_REQUEST.name());
		errors.put("error", Mockito.anyString());
		assertEquals(errors, exceptionHandler.handleUserExistedException(exception));
	}

	@Test
	void testDuplicateEntryException() {
		DuplicateUserEntryException exception = new DuplicateUserEntryException(Mockito.anyString());
		Map<String, String> errors = new LinkedHashMap<>();
		errors.put("time", new Date().toString());
		errors.put("status", HttpStatus.BAD_REQUEST.name());
		errors.put("error", Mockito.anyString());
		assertEquals(errors, exceptionHandler.handleDuplicateException(exception));
	}

	@Test
	void testNoBookFoundException() {
		NoUserFoundException exception = new NoUserFoundException(Mockito.anyString());
		Map<String, String> errors = new LinkedHashMap<>();
		errors.put("time", new Date().toString());
		errors.put("status", HttpStatus.BAD_REQUEST.name());
		errors.put("error", Mockito.anyString());
		assertEquals(errors, exceptionHandler.handleNoUserFoundException(exception));
	}

	@Test
	void handleMethodArgumentsTest() {
		Map<String, String> errors = new LinkedHashMap<>();
		errors.put("time", new Date().toString());
		errors.put("status", HttpStatus.BAD_REQUEST.name());
		errors.put("error", Mockito.anyString());
		assertEquals(errors, exceptionHandler.handelMethodArgumentException(MethodArgumentNotValidException));
	}
}
