package com.example.users;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.hamcrest.Matchers;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.example.users.controllerlayer.UserController;
import com.example.users.databaselayer.UserEntity;
import com.example.users.dtolayer.UserDTO;
import com.example.users.exceptionlayer.DuplicateUserEntryException;
import com.example.users.exceptionlayer.NoUserFoundException;
import com.example.users.exceptionlayer.UserExistedException;
import com.example.users.servicelayer.UserService;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest
class UserControllerTest {

	private MockMvc mockMvc;
	@InjectMocks
	private UserController controller;
	@Mock
	private UserService userService;
	private UserDTO userDto;
	private UserEntity userEntity;

	@BeforeEach
	public void setUp() {
		userDto = new UserDTO();
		userEntity = new UserEntity();
		mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
	}

	@Test
	void testSaveUser() throws UserExistedException {
		when(userService.save(userDto)).thenReturn(userEntity);
		assertEquals(userEntity,controller.saveUser(userDto));
	}

	@Test
	void testUpdateUser() throws DuplicateUserEntryException {
		when(userService.update(userDto)).thenReturn(userEntity);
		assertEquals(userEntity,controller.updateUser(userDto));
	}

	@Test
	void testDeleteUser() throws NoUserFoundException {
		doNothing().when(userService).delete(Mockito.anyString());
		assertEquals(HttpStatus.OK,controller.deleteUser(Mockito.anyString()));
	}

	@Test
	void testGetAllUsers() throws Exception {
		List<UserEntity> entities = new ArrayList<>();
		entities.add(userEntity);
		when(userService.findAll()).thenReturn(entities);
		mockMvc.perform(get("/users").accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
				.andExpect(jsonPath("[0].userName", Matchers.is(userEntity.getUserName())))
				.andExpect(jsonPath("[0].emailId", Matchers.is(userEntity.getEmailId())))
				.andExpect(jsonPath("[0].name", Matchers.is(userEntity.getName())));
	}

	@Test
	void testGetUser() throws Exception {
		when(userService.findById(Mockito.anyString())).thenReturn(userEntity);
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.findAndRegisterModules();
		userEntity.setUserName("abc");
		mockMvc.perform(get("/users/{userId}", userEntity.getUserName()).accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk());
	}
}
