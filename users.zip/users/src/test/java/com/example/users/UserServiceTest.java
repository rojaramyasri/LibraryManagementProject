package com.example.users;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.users.databaselayer.UserEntity;
import com.example.users.databaselayer.UserRepository;
import com.example.users.dtolayer.UserDTO;
import com.example.users.exceptionlayer.DuplicateUserEntryException;
import com.example.users.exceptionlayer.NoUserFoundException;
import com.example.users.exceptionlayer.UserExistedException;
import com.example.users.servicelayer.UserService;

@SpringBootTest
class UserServiceTest {

	@InjectMocks
	private UserService userService;
	@Mock
	private UserRepository userRepo;
	private UserDTO userDto;
	private UserEntity userEntity;

	@BeforeEach
	public void setUp() {
		userDto = new UserDTO();
		userDto.setEmailId("abc@gmail.com");
		userDto.setName("ramya");
		userDto.setUserName("sri");
	}

	@Test
	void testSaveBookException() throws UserExistedException {
		userEntity = new UserEntity();
		userEntity.setUserName("ramya");
		when(userRepo.findById(Mockito.anyString())).thenReturn(Optional.ofNullable(userEntity));
		assertThrows(UserExistedException.class, () -> {
			userService.save(userDto);
		});
	}

	@Test
	void testSaveBook() throws UserExistedException {
		when(userRepo.findById(Mockito.anyString())).thenReturn(Optional.ofNullable(userEntity));
		when(userRepo.save(Mockito.any(UserEntity.class))).thenReturn(Mockito.any(UserEntity.class));
		userService.save(userDto);
		verify(userRepo, atLeastOnce()).save(Mockito.any(UserEntity.class));

	}

	@Test
	void testUpdateBook() throws DuplicateUserEntryException {
		userEntity = new UserEntity();
		userEntity.setUserName("ramya");
		when(userRepo.findById(Mockito.anyString())).thenReturn(Optional.ofNullable(userEntity));
		when(userRepo.save(Mockito.any(UserEntity.class))).thenReturn(Mockito.any(UserEntity.class));
		userService.update(userDto);
		verify(userRepo, atLeastOnce()).save(Mockito.any(UserEntity.class));
	}

	@Test
	void testUpdateBookException() throws DuplicateUserEntryException {
		when(userRepo.findById(Mockito.anyString())).thenReturn(Optional.ofNullable(userEntity));
		assertThrows(DuplicateUserEntryException.class, () -> {
			userService.update(userDto);
		});

	}

	@Test
	void testFindByIdException() {
		when(userRepo.findById(Mockito.anyString())).thenReturn(Optional.ofNullable(userEntity));
		assertThrows(NoUserFoundException.class, () -> {
			userService.findById(Mockito.anyString());
		});
	}

	@Test
	void testFindById() throws NoUserFoundException {
		userEntity = new UserEntity();
		when(userRepo.findById(Mockito.anyString())).thenReturn(Optional.ofNullable(userEntity));
		userService.findById("1");
		assertEquals(userEntity, userService.findById(Mockito.anyString()));
	}

	@Test
	void testFindAll() {
		List<UserEntity> entities = new ArrayList<>();
		userEntity = new UserEntity();
		when(userService.findAll()).thenReturn(entities);
		assertEquals(entities, userService.findAll());
	}

	@Test
	void testDeleteBook() throws NoUserFoundException {
		when(userRepo.findById(Mockito.anyString())).thenReturn(Optional.ofNullable(userEntity));
		assertThrows(NoUserFoundException.class, () -> {
			userService.delete(Mockito.anyString());
		});
		userEntity = new UserEntity();
		userEntity.setUserName("ramya");
		when(userRepo.findById(Mockito.anyString())).thenReturn(Optional.ofNullable(userEntity));
		doNothing().when(userRepo).delete(userEntity);
		userService.delete("1");
		verify(userRepo, atLeastOnce()).delete(Mockito.any(UserEntity.class));
	}

}
