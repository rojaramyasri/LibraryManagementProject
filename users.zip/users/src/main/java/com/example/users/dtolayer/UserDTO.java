package com.example.users.dtolayer;

import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserDTO {
	
	@NotNull(message = "User name should not be null")
	private String userName;
	
	@NotNull(message = "name should not be null")
	private String name;
	
	private String emailId;
}
