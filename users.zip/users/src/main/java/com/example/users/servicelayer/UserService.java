package com.example.users.servicelayer;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.users.databaselayer.UserEntity;
import com.example.users.databaselayer.UserRepository;
import com.example.users.dtolayer.UserDTO;
import com.example.users.exceptionlayer.DuplicateUserEntryException;
import com.example.users.exceptionlayer.NoUserFoundException;
import com.example.users.exceptionlayer.UserExistedException;

@Service
public class UserService {

	@Autowired
	private UserRepository userRepo;

	public UserEntity save(UserDTO userDto) throws UserExistedException {
		ModelMapper mapper = new ModelMapper();
		UserEntity userEntity = mapper.map(userDto, UserEntity.class);
		if (userRepo.findById(userEntity.getUserName()).isPresent()) {
			throw new UserExistedException("User with given user name existed");
		}
		return userRepo.save(userEntity);
	}

	public UserEntity update(UserDTO userDto) throws DuplicateUserEntryException {
		ModelMapper mapper = new ModelMapper();
		UserEntity userEntity = mapper.map(userDto, UserEntity.class);
		if (!userRepo.findById(userEntity.getUserName()).isPresent()) {
			throw new DuplicateUserEntryException("User alredy Existed");
		}
		return userRepo.save(userEntity);
	}

	public UserEntity findById(String userName) throws NoUserFoundException {
		return userRepo.findById(userName).orElseThrow(() -> new NoUserFoundException("Usernname is  not existed"));
	}

	public List<UserEntity> findAll() {
		return userRepo.findAll();
	}

	public void delete(String userName) throws NoUserFoundException {
		UserEntity userEntity = userRepo.findById(userName)
				.orElseThrow(() -> new NoUserFoundException("No user found with given user name "));
		userRepo.delete(userEntity);
	}

}
