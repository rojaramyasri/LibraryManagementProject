package com.example.users.exceptionlayer;

public class UserExistedException extends Exception {
	private static final long serialVersionUID = 1L;

	public UserExistedException(String message) {
		super(message);
	}
}
