package com.example.users.exceptionlayer;

import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class UserExceptionalHandler {
	
	@ExceptionHandler(MethodArgumentNotValidException.class)
	@ResponseStatus(code = HttpStatus.BAD_REQUEST)
	public Map<String, String> handelMethodArgumentException(MethodArgumentNotValidException exception) {
		Map<String, String> errors = new LinkedHashMap<>();
		StringBuilder message = new StringBuilder();
		errors.put("time", new Date().toString());
		errors.put("status", HttpStatus.BAD_REQUEST.name());
		errors.put("error", message.toString());
		return errors;
	}

	@ExceptionHandler(NoUserFoundException.class)
	@ResponseStatus(code = HttpStatus.BAD_REQUEST)
	public Map<String, String> handleNoUserFoundException(NoUserFoundException exception) {
		Map<String, String> errors = new LinkedHashMap<>();
		errors.put("time", new Date().toString());
		errors.put("status", HttpStatus.BAD_REQUEST.name());
		errors.put("error", exception.getMessage());
		return errors;
	}

	@ExceptionHandler(DuplicateUserEntryException.class)
	@ResponseStatus(code = HttpStatus.BAD_REQUEST)
	public Map<String, String> handleDuplicateException(DuplicateUserEntryException exception) {
		Map<String, String> errors = new LinkedHashMap<>();
		errors.put("time", new Date().toString());
		errors.put("status", HttpStatus.BAD_REQUEST.name());
		errors.put("error", exception.getMessage());
		return errors;
	}

	@ExceptionHandler(UserExistedException.class)
	@ResponseStatus(code = HttpStatus.BAD_REQUEST)
	public Map<String, String> handleUserExistedException(UserExistedException exception) {
		Map<String, String> errors = new LinkedHashMap<>();
		errors.put("time", new Date().toString());
		errors.put("status", HttpStatus.BAD_REQUEST.name());
		errors.put("error", exception.getMessage());
		return errors;
	}
}
