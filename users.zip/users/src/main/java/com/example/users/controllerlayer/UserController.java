package com.example.users.controllerlayer;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.users.databaselayer.UserEntity;
import com.example.users.dtolayer.UserDTO;
import com.example.users.exceptionlayer.DuplicateUserEntryException;
import com.example.users.exceptionlayer.NoUserFoundException;
import com.example.users.exceptionlayer.UserExistedException;
import com.example.users.servicelayer.UserService;

import io.swagger.annotations.Api;

@RestController
@Api
public class UserController {

	@Autowired
	private UserService userService;

	@PostMapping("/users")
	public UserEntity saveUser(@RequestBody @Valid UserDTO userDto) throws UserExistedException {
		return userService.save(userDto);
	}

	@PutMapping("/users")
	public UserEntity updateUser(@RequestBody @Valid UserDTO userDto) throws DuplicateUserEntryException {
		return userService.update(userDto);
	}

	@GetMapping("/users/{userId}")
	public UserEntity getUser(@PathVariable String userId) throws NoUserFoundException {
		return userService.findById(userId);
	}

	@GetMapping("/users")
	public List<UserEntity> getUsers() {
		return userService.findAll();
	}

	@DeleteMapping("/users/{userId}")
	public HttpStatus deleteUser(@PathVariable String userId) throws NoUserFoundException {
		userService.delete(userId);
		return HttpStatus.OK;
	}
}