package com.example.users.exceptionlayer;

public class DuplicateUserEntryException extends Exception {
	private static final long serialVersionUID = 1L;

	public DuplicateUserEntryException(String message) {
		super(message);
	}
}
